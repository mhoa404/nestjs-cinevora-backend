# Database Schema Current

## Purpose
File này mô tả schema database hiện tại của Cinevora backend dựa trên:
- TypeORM entities hiện có
- TypeORM migrations hiện có
- quan hệ thực tế giữa các bảng

Tài liệu này dùng để hiểu nhanh database structure và làm nguồn tham chiếu khi sửa entity, migration, service hoặc test liên quan DB.

## Source of Truth
Ưu tiên đọc theo thứ tự:
1. `src/database/migrations/*`
2. `src/modules/**/entities/*.entity.ts`
3. service/module liên quan
4. ERD hình ảnh chỉ để nhìn tổng quan, không phải nguồn sự thật tuyệt đối

## Database Engine
- DBMS: MySQL
- ORM: TypeORM
- Strategy: dùng migrations, không dùng `synchronize: true`

---

## 1. users
### Purpose
Lưu thông tin tài khoản người dùng và phân quyền.

### Columns
- `id` uuid PK
- `full_name` varchar(100)
- `email` varchar(150), unique
- `password` varchar(255)
- `date_of_birth` date
- `phone` varchar(15), unique, nullable theo entity type nhưng DB column không khai báo nullable
- `city` varchar(50), nullable
- `district` varchar(50), nullable
- `address` varchar(255), nullable
- `sex` enum: `Nam`, `Nữ`, `Khác`, nullable
- `id_card_number` varchar(20), unique, nullable
- `role` enum: `customer`, `staff`, `admin`, `super_admin`, default `customer`
- `is_active` boolean, default true
- `last_login_at` datetime, nullable
- `created_at` datetime
- `updated_at` datetime

### Relations
- 1 user -> n bookings
- 1 user -> n refresh_tokens qua `RefreshToken.user`

### Notes
- Service kiểm tra unique email và phone khi tạo user.
- Password được hash bằng bcrypt trước khi lưu.

---

## 2. refresh_tokens
### Purpose
Lưu refresh token đã hash để phục vụ session và refresh token rotation.

### Columns
- `id` PK
- `user_id` FK -> `users.id`
- `token` unique, SHA-256 hash
- `expires_at`
- `is_revoked`
- `created_at`

### Relations
- n refresh_tokens -> 1 user

### Notes
- Không lưu raw refresh token trong DB.
- Token bị revoke khi logout hoặc khi refresh thành công.

---

## 3. genres
### Purpose
Lưu danh sách thể loại phim.

### Columns
- `id` PK
- `name` unique
- `slug` unique
- `created_at`

### Relations
- n genres <-> n movies thông qua bảng join `movie_genre`

### Notes
- `slug` generate từ `name`.
- Service kiểm tra trùng `name` bằng `LOWER(genre.name)` và kiểm tra trùng `slug`.

---

## 4. movies
### Purpose
Lưu thông tin phim.

### Columns
- `id` PK
- `title` varchar(255)
- `slug` varchar(255), unique, nullable
- `poster_url` text
- `trailer_url` text, nullable
- `banner_url` text, nullable
- `description` text, nullable
- `duration` int
- `director` varchar(200), nullable
- `actor` text, nullable
- `language` varchar(50), nullable
- `age_rating` enum: `P`, `C13`, `C16`, `C18`
- `rated` varchar(100), nullable
- `status` enum: `now_showing`, `upcoming`, `ended`, default `upcoming`
- `release_date` date
- `end_date` date, nullable
- `avg_rating` decimal(3,1), nullable
- `created_at` timestamp
- `updated_at` timestamp

### Relations
- 1 movie -> n showtimes
- n movies <-> n genres qua `movie_genre`

### Notes
- Service build slug theo format `baseSlug-id` sau khi tạo movie.
- `findOne` hỗ trợ nhận numeric id hoặc slug qua `slugOrId`.
- Xoá phim chỉ cho phép khi status là `ended`.

---

## 5. movie_genre
### Purpose
Bảng join many-to-many giữa movies và genres.

### Columns
- `movie_id` PK, FK -> `movies.id`
- `genre_id` PK, FK -> `genres.id`

### Relations
- n movie_genre -> 1 movie
- n movie_genre -> 1 genre

### Notes
- Entity hiện tại dùng `@JoinTable({ name: 'movie_genre' })`.
- Một số migration cũ có nhắc `movie_genres`, nhưng entity/current migration mới dùng `movie_genres` thì phải kiểm tra lại source thật. Theo entity hiện tại, tên đúng là `movie_genre`.

---

## 6. rooms
### Purpose
Lưu phòng chiếu.

### Columns
- `id` PK
- `name` varchar(20), unique
- `created_at` timestamp
- `updated_at` timestamp

### Relations
- 1 room -> n seats
- 1 room -> n showtimes

### Notes
- DTO yêu cầu `name` theo format 2 chữ số: `01`, `02`, `03`...
- Service trả thêm `totalSeats` bằng relation count.
- Chặn xoá phòng nếu phòng đang có showtime.
- Migration cũ từng có `room_type`, nhưng entity hiện tại không còn field này.

---

## 7. seats
### Purpose
Lưu ghế của từng phòng.

### Columns
- `id` PK
- `room_id` FK -> `rooms.id`
- `seat_key`
- `row_label`
- `seat_number`
- `seat_type` enum: `standard`, `vip`, `premium`, `couple`
- `is_active`
- `created_at`
- `updated_at`

### Relations
- n seats -> 1 room
- 1 seat -> n booking_seats

### Notes
- Module seats hiện có entity, service/controller còn rỗng.

---

## 8. showtimes
### Purpose
Lưu suất chiếu của phim trong từng phòng.

### Columns
- `id` PK
- `movie_id` FK -> `movies.id`
- `room_id` FK -> `rooms.id`
- `start_time` timestamp/datetime theo migration/entity
- `end_time` timestamp/datetime theo migration/entity
- `status` enum: `open`, `sold_out`, default `open`
- `price_standard` decimal(10,0)
- `price_vip` decimal(10,0)
- `price_couple` decimal(10,0), nullable
- `created_at` timestamp
- `updated_at` timestamp

### Relations
- n showtimes -> 1 movie
- n showtimes -> 1 room
- 1 showtime -> n bookings

### Notes
- `endTime` không nhập trực tiếp khi create, service tự tính bằng `startTime + movie.duration`.
- Service kiểm tra trùng lịch theo room với buffer 30 phút.
- Delete chỉ cho phép nếu movie đang ở status `ended`.

---

## 9. bookings
### Purpose
Lưu đơn đặt vé.

### Columns
- `id` PK
- `user_id` FK -> `users.id`
- `showtime_id` FK -> `showtimes.id`
- `ticket_count` int
- `total_price` decimal(10,0)
- `payment_method` enum: `cash`, `momo`, `zalopay`, `credit_card`
- `booked_at` timestamp
- `status` enum: `pending`, `confirmed`, `cancelled`, `used`, default `pending`
- `snapshot_movie_title` varchar(255)
- `snapshot_cinema_name` varchar(100)
- `snapshot_room_name` varchar(20)
- `snapshot_showtime_start` timestamp
- `created_at` timestamp
- `updated_at` timestamp

### Relations
- n bookings -> 1 user
- n bookings -> 1 showtime
- 1 booking -> n booking_seats

### Notes
- Entity đã có snapshot fields để giữ dữ liệu tại thời điểm đặt vé.
- Module bookings hiện service/controller còn rỗng.

---

## 10. booking_seats
### Purpose
Lưu từng ghế trong một booking.

### Columns
- `id` PK
- `booking_id` FK -> `bookings.id`
- `seat_id` FK -> `seats.id`
- `seat_key` varchar(10)
- `price` decimal(10,0)
- `snapshot_seat_type` enum: `standard`, `vip`, `premium`, `couple`, default `standard`
- `created_at` timestamp
- `updated_at` timestamp

### Relations
- n booking_seats -> 1 booking
- n booking_seats -> 1 seat

---

## 11. promotions
### Purpose
Lưu chương trình khuyến mãi/banner.

### Columns
- `id` PK
- `title` varchar(255)
- `description` text, nullable
- `image_url` text, nullable
- `discount_percent` decimal(5,2), nullable
- `promotion_type` enum: `highlight`, `grid`, `top`, default `grid`
- `start_date` date, nullable
- `end_date` date, nullable
- `is_active` boolean, default true
- `created_at` timestamp

### Notes
- Entity đã có.
- Service/controller hiện còn rỗng.
