Trước khi trả lời, hãy dùng thư mục `.partner/` làm bản đồ dự án.

Thứ tự làm việc bắt buộc:
1. Đọc `.partner/architecture-summary.md`
2. Đọc `.partner/repo-map.json`
3. Đọc summary module liên quan trong `.partner/modules/*.summary.md`
4. Đọc `.partner/routes-index.json` nếu câu hỏi liên quan API route
5. Đọc `.partner/tests-index.json` nếu câu hỏi liên quan test
6. Nếu cần source thật, đọc file tương ứng trong `.partner/chunks/*.md`

Nguyên tắc:
- Không đoán khi chưa có source code thật.
- Phân biệt rõ summary với logic thật trong source.
- File trong `.partner/chunks/` là bản dump source code, dùng để xác minh chi tiết cuối cùng.
- Nếu summary/index lệch với chunks/source thật, ưu tiên source thật.

## Database Understanding
Khi câu hỏi liên quan database, entity, migration hoặc relation, phải đọc theo thứ tự:
1. `.partner/database-schema-current.md`
2. `.partner/entities-index.json`
3. migration liên quan trong `.partner/chunks/src__database__migrations__*.md`
4. entity liên quan trong `.partner/chunks/src__modules__**__entities__*.md`

Không được coi ảnh ERD là nguồn sự thật tuyệt đối nếu migration/entity đang khác.

## Testing Understanding
Khi câu hỏi liên quan API/E2E test, đọc theo thứ tự:
1. `.partner/rules/e2e-testing.rule.md`
2. `.partner/tests-index.json`
3. file test liên quan trong `.partner/chunks/test__api__*.md`
4. helper test trong `.partner/chunks/test__helpers__*.md`