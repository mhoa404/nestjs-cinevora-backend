# Showtimes Module Summary

## Status
Implemented core CRUD.

## Key Files
- `src/modules/showtimes/showtimes.controller.ts`
- `src/modules/showtimes/showtimes.service.ts`
- `src/modules/showtimes/entities/showtime.entity.ts`
- `src/modules/showtimes/dto/create-showtime.dto.ts`
- `src/modules/showtimes/dto/update-showtime.dto.ts`
- `src/modules/showtimes/dto/showtime-query.dto.ts`
- `src/modules/showtimes/dto/showtime-response.dto.ts`

## Routes
- `POST /showtimes` — admin/super_admin, tạo một hoặc nhiều suất chiếu.
- `GET /showtimes` — public, lọc được theo `movieId`, `roomId`, `date`.
- `GET /showtimes/:id` — public.
- `PATCH /showtimes/:id` — admin/super_admin.
- `DELETE /showtimes/:id` — admin/super_admin.

## DTO Rules
### CreateShowtimeDto
- `movieId`: required int.
- `showtimes`: required array, min size 1.
- Mỗi item gồm:
  - `roomId`: required int.
  - `startTime`: required ISO 8601 date string.
  - `status`: optional enum `open | sold_out`.
  - `priceStandard`: required int, min 0.
  - `priceVip`: required int, min 0.
  - `priceCouple`: optional int, min 0.

### UpdateShowtimeDto
Optional fields:
- `roomId`
- `startTime`
- `status`
- `priceStandard`
- `priceVip`
- `priceCouple`

### ShowtimeQueryDto
Optional query:
- `movieId`
- `roomId`
- `date`

## Business Rules
- `movieId` phải tồn tại.
- `roomId` phải tồn tại.
- `endTime` được tự tính bằng `startTime + movie.duration`.
- Phòng không được trùng lịch chiếu.
- Có buffer 30 phút sau `endTime` khi kiểm tra overlap.
- Create dùng transaction `SERIALIZABLE`.
- Create lock room bằng pessimistic write.
- Update nếu đổi `roomId` hoặc `startTime` thì kiểm tra overlap lại.
- Delete chỉ cho phép khi movie của showtime có status `ended`.

## Response
`ShowtimeResponseDto` trả:
- `id`
- `movieId`
- `movieTitle`
- `roomId`
- `roomName`
- `startTime`
- `endTime`
- `status`
- `priceStandard`
- `priceVip`
- `priceCouple`
- `createdAt`
- `updatedAt`

## Notes
- `findAll` order theo `showtime.start_time ASC`.
- `date` query đang được convert theo UTC day range: `YYYY-MM-DDT00:00:00Z` đến `YYYY-MM-DDT23:59:59.999Z`.
- Hiện chưa có API test index cho showtimes trong `tests-index.json`.