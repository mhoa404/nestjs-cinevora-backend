# Movies Module Summary

## Purpose
Quản lý phim và quan hệ với genres.

## Main Files
- `src/modules/movies/movies.controller.ts`
- `src/modules/movies/movies.service.ts`
- `src/modules/movies/utils/movie-input.util.ts`
- `src/modules/movies/entities/movie.entity.ts`
- `src/modules/movies/dto/create-movie.dto.ts`
- `src/modules/movies/dto/update-movie.dto.ts`
- `src/modules/movies/dto/movie-response.dto.ts`

## Routes
### Public
- `GET /movies`
- `GET /movies/:slugOrId`

### Admin / Super Admin
- `POST /movies`
- `PUT /movies/:id`
- `DELETE /movies/:id`

## Key Behaviors
### Create
- Validate `endDate` nếu có.
- Normalize input text fields bằng `prepareMovieInput`.
- Validate `genreIds` tồn tại trong DB.
- Save movie lần 1 để lấy id.
- Build slug theo format `baseSlug-id_pad_3`.
- Save lần 2 để cập nhật slug.

### Read
- `findAll` load relation `genres`, order theo `createdAt DESC`.
- `findOneBySlugOrId` hỗ trợ:
  - nếu param toàn số -> tìm theo id
  - ngược lại -> tìm theo slug

### Update
- Find movie theo id.
- Validate `endDate` nếu có.
- Normalize input.
- Validate `genreIds`.
- Rebuild slug theo title mới và id hiện tại.
- Update relation genres.

### Delete
- Chỉ được xoá khi `movie.status === MovieStatus.ENDED` (`ended`).

## Validation Rules
- `title`: required string, max 255.
- `posterUrl`: required URL.
- `trailerUrl`: optional URL.
- `bannerUrl`: URL field trong DTO.
- `duration`: int, min 1.
- `director`: optional string, max 200.
- `actor`: optional string.
- `language`: optional string, max 50.
- `ageRating`: enum `P | C13 | C16 | C18`.
- `rated`: optional string, max 100.
- `status`: optional enum `now_showing | upcoming | ended`, default service là `upcoming`.
- `releaseDate`: required date string.
- `endDate`: optional date string.
- `genreIds`: optional number array, tất cả id phải tồn tại.

## End Date Rule
Nếu có `endDate`:
- `endDate` phải cách ít nhất 7 ngày kể từ hôm nay.
- `endDate` phải sau `releaseDate` nếu có `releaseDate`.

## Slug Rule
Slug không chỉ là title slugify, mà là:
`{baseSlug}-{id_pad_3}`

Ví dụ:
- title: `Thiên Đường Máu`
- slug base: `thien-duong-mau`
- id: `1`
- final slug: `thien-duong-mau-001`

## Response
`MovieResponseDto` trả:
- `id`, `title`, `slug`
- `posterUrl`, `trailerUrl`, `bannerUrl`
- `description`, `duration`, `director`, `actor`, `language`
- `ageRating`, `rated`, `status`
- `releaseDate`, `endDate`, `avgRating`, `createdAt`
- `genres`

## Related Tests
- `test/api/movies/create-movie.api.spec.ts`
- `test/api/movies/update-movie.api.spec.ts`
- `test/api/movies/delete-movie.api.spec.ts`
