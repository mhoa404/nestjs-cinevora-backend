# FILE: src/database/migrations/1710000000003-CreateShowtimes.ts

path: src/database/migrations/1710000000003-CreateShowtimes.ts
module: database
kind: migration
language: ts
line_count: 47
size_bytes: 2032
sha256: ac83d02a3838d0f1e513498a587792a7de428e832f95067779982684c1b94dd3
updated_at: 2026-04-23T17:32:06.386Z

## SYMBOLS
- CreateShowtimes1710000000003

## CODE

````ts
import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateShowtimes1710000000003 implements MigrationInterface {
  name = 'CreateShowtimes1710000000003';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE \`showtimes\` (
        \`id\`              INT             NOT NULL AUTO_INCREMENT,
        \`movie_id\`        INT             NOT NULL,
        \`room_id\`         INT             NOT NULL,
        \`start_time\`      DATETIME        NOT NULL,
        \`end_time\`        DATETIME        NOT NULL,
        \`status\`          ENUM('open', 'sold_out') NOT NULL DEFAULT 'open',
        \`price_standard\`  DECIMAL(10,0)   NOT NULL,
        \`price_vip\`       DECIMAL(10,0)   NOT NULL,
        \`price_couple\`    DECIMAL(10,0)   NULL,
        \`created_at\`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT \`PK_showtimes\` PRIMARY KEY (\`id\`),
        CONSTRAINT \`FK_showtimes_movie\` FOREIGN KEY (\`movie_id\`)
          REFERENCES \`movies\`(\`id\`) ON DELETE CASCADE,
        CONSTRAINT \`FK_showtimes_room\` FOREIGN KEY (\`room_id\`)
          REFERENCES \`rooms\`(\`id\`) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(
      `CREATE INDEX \`IDX_showtimes_movie_id\` ON \`showtimes\`(\`movie_id\`)`,
    );

    await queryRunner.query(
      `CREATE INDEX \`IDX_showtimes_room_start\` ON \`showtimes\`(\`room_id\`, \`start_time\`)`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX \`IDX_showtimes_room_start\` ON \`showtimes\``,
    );
    await queryRunner.query(
      `DROP INDEX \`IDX_showtimes_movie_id\` ON \`showtimes\``,
    );
    await queryRunner.query(`DROP TABLE \`showtimes\``);
  }
}

````
