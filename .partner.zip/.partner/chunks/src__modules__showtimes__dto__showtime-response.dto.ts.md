# FILE: src/modules/showtimes/dto/showtime-response.dto.ts

path: src/modules/showtimes/dto/showtime-response.dto.ts
module: showtimes
kind: dto
language: ts
line_count: 39
size_bytes: 1172
sha256: 8348d75e81774c9b12751975eafc9d5cbfa5660a167110ec5c8343a76993a562
updated_at: 2026-04-25T11:05:15.853Z

## SYMBOLS
- ShowtimeResponseDto

## CODE

````ts
import { Showtime, ShowtimeStatus } from '../entities/showtime.entity';

export class ShowtimeResponseDto {
  id!: number;
  movieId!: number;
  movieTitle!: string;
  roomId!: number;
  roomName!: string;
  startTime!: string;
  endTime!: string;
  status!: ShowtimeStatus;
  priceStandard!: number;
  priceVip!: number;
  priceCouple!: number | null;
  createdAt!: string;
  updatedAt!: string;

  static fromEntity(entity: Showtime): ShowtimeResponseDto {
    const dto = new ShowtimeResponseDto();

    dto.id = entity.id;
    dto.movieId = entity.movieId;
    dto.movieTitle = entity.movie?.title ?? '';
    dto.roomId = entity.roomId;
    dto.roomName = entity.room?.name ?? '';
    dto.startTime = entity.startTime.toISOString();
    dto.endTime = entity.endTime.toISOString();
    dto.status = entity.status;
    dto.priceStandard = Number(entity.priceStandard);
    dto.priceVip = Number(entity.priceVip);
    dto.priceCouple =
      entity.priceCouple != null ? Number(entity.priceCouple) : null;
    dto.createdAt = entity.createdAt.toISOString();
    dto.updatedAt = entity.updatedAt.toISOString();

    return dto;
  }
}

````
