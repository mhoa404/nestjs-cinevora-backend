# FILE: src/modules/rooms/dto/room-response.dto.ts

path: src/modules/rooms/dto/room-response.dto.ts
module: rooms
kind: dto
language: ts
line_count: 20
size_bytes: 508
sha256: 622c842155e0e545714708b9e690008859c7e18eaf4a47c25193fe14812642a2
updated_at: 2026-04-22T22:25:10.217Z

## SYMBOLS
- RoomResponseDto

## CODE

````ts
import { Room } from '../entities/room.entity';

export class RoomResponseDto {
  id!: number;
  name!: string;
  totalSeats!: number;
  createdAt!: Date;
  updatedAt!: Date;

  static fromEntity(entity: Room & { totalSeats?: number }): RoomResponseDto {
    const dto = new RoomResponseDto();
    dto.id = entity.id;
    dto.name = entity.name;
    dto.totalSeats = entity.totalSeats || 0;
    dto.createdAt = entity.createdAt;
    dto.updatedAt = entity.updatedAt;
    return dto;
  }
}

````
