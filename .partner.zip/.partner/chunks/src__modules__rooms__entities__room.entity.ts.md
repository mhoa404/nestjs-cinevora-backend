# FILE: src/modules/rooms/entities/room.entity.ts

path: src/modules/rooms/entities/room.entity.ts
module: rooms
kind: entity
language: ts
line_count: 42
size_bytes: 890
sha256: c87dc70f8665a243ee5b83f9230f9ac497c107225ed5974f78873a15aa618ad3
updated_at: 2026-04-24T08:26:30.364Z

## SYMBOLS
- Room

## CODE

````ts
import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

import { Seat } from '../../seats/entities/seat.entity';
import { Showtime } from '../../showtimes/entities/showtime.entity';

@Entity('rooms')
export class Room {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ length: 20, unique: true })
  name!: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    default: () => 'CURRENT_TIMESTAMP',
    onUpdate: 'CURRENT_TIMESTAMP',
  })
  updatedAt!: Date;

  @OneToMany(() => Showtime, (showtime) => showtime.room)
  showtimes!: Showtime[];

  @OneToMany(() => Seat, (seat) => seat.room)
  seats!: Seat[];
}

````
