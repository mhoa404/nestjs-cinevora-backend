# FILE: src/common/constants/seat-type.constant.ts

path: src/common/constants/seat-type.constant.ts
module: common
kind: file
language: ts
line_count: 6
size_bytes: 91
sha256: fdae5c862fc7a34b57da55838be5c262b4e26d7ebdf4dc7b1afe001bc9b9896d
updated_at: 2026-04-23T17:32:06.378Z

## SYMBOLS
- (none detected)

## CODE

````ts
export enum SeatType {
  STANDARD = 'standard',
  VIP = 'vip',
  COUPLE = 'couple',
}

````
