# FILE: src/modules/rooms/dto/create-room.dto.ts

path: src/modules/rooms/dto/create-room.dto.ts
module: rooms
kind: dto
language: ts
line_count: 12
size_bytes: 469
sha256: 8393d8181494b42527bf81de2c06791b38a2640af1980fa65cf21ce5e7d1ed4c
updated_at: 2026-04-22T22:25:10.216Z

## SYMBOLS
- CreateRoomDto

## CODE

````ts
import { IsNotEmpty, IsString, Matches, MaxLength } from 'class-validator';

export class CreateRoomDto {
  @IsString({ message: 'Tên phòng phải là chuỗi' })
  @IsNotEmpty({ message: 'Tên phòng không được để trống' })
  @MaxLength(20, { message: 'Tên phòng không được vượt quá 20 ký tự' })
  @Matches(/^[0-9]{2}$/, {
    message: 'Tên phòng phải theo định dạng 01, 02, 03... (2 chữ số)',
  })
  name!: string;
}

````
