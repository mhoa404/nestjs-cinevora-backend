# FILE: src/config/app.config.ts

path: src/config/app.config.ts
module: config
kind: config
language: ts
line_count: 7
size_bytes: 190
sha256: 108b911f35b555e5bdfbf81af9586101153fa27209d4e8eccaf8d68b9e649be7
updated_at: 2026-04-24T01:07:11.971Z

## SYMBOLS
- (none detected)

## CODE

````ts
import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  port: parseInt(process.env.PORT ?? '3000', 10),
  frontendUrl: process.env.FRONTEND_URL,
}));

````
