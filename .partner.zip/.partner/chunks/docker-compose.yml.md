# FILE: docker-compose.yml

path: docker-compose.yml
module: root
kind: file
language: yaml
line_count: 71
size_bytes: 1645
sha256: 0fae4f8ad6d0f1d434d246c0719c002e63482a43dbc90274635835682531b480
updated_at: 2026-04-14T14:32:33.391Z

## SYMBOLS
- (none detected)

## CODE

````yaml
services:
  mysql:
    image: mysql:8.0
    container_name: cinevora_mysql
    restart: unless-stopped
    command:
      - --default-authentication-plugin=mysql_native_password
      - --character-set-server=utf8mb4
      - --collation-server=utf8mb4_unicode_ci
    env_file:
      - .env
    environment:
      MYSQL_ROOT_PASSWORD: ${DB_ROOT_PASSWORD}
      MYSQL_DATABASE: ${DB_NAME}
      MYSQL_USER: ${DB_USER}
      MYSQL_PASSWORD: ${DB_PASSWORD}
    ports:
      - "127.0.0.1:3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
    healthcheck:
      test: ["CMD-SHELL", "mysqladmin ping -h 127.0.0.1 -uroot -p$$MYSQL_ROOT_PASSWORD --silent"]
      interval: 10s
      timeout: 5s
      retries: 10
      start_period: 20s
    networks:
      - cinevora_network

  backend:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: cinevora_backend
    restart: unless-stopped
    depends_on:
      mysql:
        condition: service_healthy
    env_file:
      - .env
    environment:
      NODE_ENV: production
      PORT: 3000
      DB_HOST: mysql
      DB_PORT: 3306
    ports:
      - "3000:3000"
    networks:
      - cinevora_network

  jenkins:
    build:
      context: .
      dockerfile: Dockerfile.jenkins
    container_name: cinevora_jenkins
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - jenkins_home:/var/jenkins_home
      - /var/run/docker.sock:/var/run/docker.sock
    networks:
      - cinevora_network

volumes:
  mysql_data:
  jenkins_home:

networks:
  cinevora_network:
    driver: bridge
````
