# FILE: src/modules/bookings/bookings.controller.spec.ts

path: src/modules/bookings/bookings.controller.spec.ts
module: bookings
kind: spec
language: ts
line_count: 21
size_bytes: 541
sha256: 3ea84dcc88d90fbc15de6830cec74e8f2b84b32023272e0d11716669c2cedf35
updated_at: 2026-05-08T08:43:44.022Z

## SYMBOLS
- (none detected)

## CODE

````ts
import { Test, TestingModule } from '@nestjs/testing';
import { BookingsController } from './bookings.controller';

describe('BookingsController', () => {
  let controller: BookingsController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BookingsController],
    }).compile();

    controller = module.get<BookingsController>(BookingsController);
  });
  
  afterEach

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

````
