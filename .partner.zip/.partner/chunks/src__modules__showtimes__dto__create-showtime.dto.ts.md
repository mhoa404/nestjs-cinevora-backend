# FILE: src/modules/showtimes/dto/create-showtime.dto.ts

path: src/modules/showtimes/dto/create-showtime.dto.ts
module: showtimes
kind: dto
language: ts
line_count: 67
size_bytes: 2083
sha256: b174d01efc1df4b8628d771180a61222ef455d82ec087a859d3e9cc7d6bc3c92
updated_at: 2026-04-25T11:03:28.099Z

## SYMBOLS
- ShowtimeItemDto
- CreateShowtimeDto

## CODE

````ts
import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNotEmpty,
  IsOptional,
  Matches,
  Min,
  ValidateNested,
} from 'class-validator';

import { ShowtimeStatus } from '../entities/showtime.entity';

const UTC_DATE_REGEX = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

export class ShowtimeItemDto {
  @Type(() => Number)
  @IsInt({ message: 'roomId phải là số nguyên.' })
  @IsNotEmpty({ message: 'Vui lòng chọn phòng chiếu.' })
  roomId!: number;

  @Matches(UTC_DATE_REGEX, {
    message: 'startTime phải là ISO 8601 UTC, ví dụ: 2026-04-25T09:34:00.000Z.',
  })
  @IsDateString({}, { message: 'startTime phải là ISO 8601 UTC.' })
  @IsNotEmpty({ message: 'Vui lòng nhập thời gian bắt đầu.' })
  startTime!: string;

  @IsOptional()
  @IsEnum(ShowtimeStatus, { message: 'status phải là open hoặc sold_out.' })
  status?: ShowtimeStatus;

  @Min(0, { message: 'Giá vé standard phải >= 0.' })
  @Type(() => Number)
  @IsInt({ message: 'Giá vé standard phải là số nguyên.' })
  @IsNotEmpty({ message: 'Vui lòng nhập giá vé standard.' })
  priceStandard!: number;

  @Min(0, { message: 'Giá vé VIP phải >= 0.' })
  @Type(() => Number)
  @IsInt({ message: 'Giá vé VIP phải là số nguyên.' })
  @IsNotEmpty({ message: 'Vui lòng nhập giá vé VIP.' })
  priceVip!: number;

  @IsOptional()
  @Type(() => Number)
  @Min(0, { message: 'Giá vé couple phải >= 0.' })
  @IsInt({ message: 'Giá vé couple phải là số nguyên.' })
  priceCouple?: number;
}

export class CreateShowtimeDto {
  @Type(() => Number)
  @IsInt({ message: 'movieId phải là số nguyên.' })
  @IsNotEmpty({ message: 'Vui lòng chọn phim.' })
  movieId!: number;

  @IsArray({ message: 'showtimes phải là một mảng.' })
  @ArrayMinSize(1, { message: 'Phải có ít nhất 1 suất chiếu.' })
  @ValidateNested({ each: true })
  @Type(() => ShowtimeItemDto)
  showtimes!: ShowtimeItemDto[];
}

````
