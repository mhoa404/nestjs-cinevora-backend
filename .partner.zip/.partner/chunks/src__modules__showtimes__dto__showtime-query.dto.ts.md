# FILE: src/modules/showtimes/dto/showtime-query.dto.ts

path: src/modules/showtimes/dto/showtime-query.dto.ts
module: showtimes
kind: dto
language: ts
line_count: 19
size_bytes: 488
sha256: 9774076d722bdd370586d1716fb012bf4670c29a5ffd2d67cdafcaa9df66d28e
updated_at: 2026-04-25T09:01:01.394Z

## SYMBOLS
- ShowtimeQueryDto

## CODE

````ts
import { Type } from 'class-transformer';
import { IsDateString, IsInt, IsOptional } from 'class-validator';

export class ShowtimeQueryDto {
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'movieId phải là số nguyên.' })
  movieId?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'roomId phải là số nguyên.' })
  roomId?: number;

  @IsOptional()
  @IsDateString({}, { message: 'date sai định dạng.' })
  date?: string;
}

````
