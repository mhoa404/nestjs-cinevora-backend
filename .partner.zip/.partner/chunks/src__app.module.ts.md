# FILE: src/app.module.ts

path: src/app.module.ts
module: root
kind: module
language: ts
line_count: 49
size_bytes: 1616
sha256: a7ea294ac053a9cb9ae2179d3c3d405d67715780a05d2a76f11770622998167c
updated_at: 2026-04-22T22:25:10.211Z

## SYMBOLS
- AppModule

## CODE

````ts
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { APP_GUARD } from '@nestjs/core';
import { Module } from '@nestjs/common';

import { PromotionsModule } from './modules/promotions/promotions.module';
import { ShowtimesModule } from './modules/showtimes/showtimes.module';
import { BookingsModule } from './modules/bookings/bookings.module';
import { MoviesModule } from './modules/movies/movies.module';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { GenresModule } from './modules/genres/genres.module';
import { UsersModule } from './modules/users/users.module';
import { RoomsModule } from './modules/rooms/rooms.module';
import { SeatsModule } from './modules/seats/seats.module';
import { AuthModule } from './modules/auth/auth.module';
import databaseConfig from './config/database.config';
import appConfig from './config/app.config';
import jwtConfig from './config/jwt.config';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [appConfig, databaseConfig, jwtConfig],
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) =>
        configService.get('database')!,
    }),
    AuthModule,
    UsersModule,
    GenresModule,
    MoviesModule,
    RoomsModule,
    SeatsModule,
    ShowtimesModule,
    BookingsModule,
    PromotionsModule,
  ],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
  ],
})
export class AppModule {}

````
