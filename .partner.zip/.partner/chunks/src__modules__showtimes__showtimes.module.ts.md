# FILE: src/modules/showtimes/showtimes.module.ts

path: src/modules/showtimes/showtimes.module.ts
module: showtimes
kind: module
language: ts
line_count: 15
size_bytes: 492
sha256: 1b2e59769e90233c07d4d3e474d7579957ebd88ca60e025aaaa14890f212ce71
updated_at: 2026-04-24T08:25:24.461Z

## SYMBOLS
- ShowtimesModule

## CODE

````ts
import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';

import { ShowtimesController } from './showtimes.controller';
import { ShowtimesService } from './showtimes.service';
import { Showtime } from './entities/showtime.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Showtime])],
  providers: [ShowtimesService],
  controllers: [ShowtimesController],
  exports: [TypeOrmModule, ShowtimesService],
})
export class ShowtimesModule {}

````
