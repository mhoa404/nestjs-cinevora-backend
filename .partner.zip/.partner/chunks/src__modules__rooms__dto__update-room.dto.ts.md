# FILE: src/modules/rooms/dto/update-room.dto.ts

path: src/modules/rooms/dto/update-room.dto.ts
module: rooms
kind: dto
language: ts
line_count: 4
size_bytes: 107
sha256: f3ab5c847f6f99c2bb515dee1499a21efd94957b1edde05b4c5d6a03a1c554c5
updated_at: 2026-04-22T22:25:10.217Z

## SYMBOLS
- UpdateRoomDto

## CODE

````ts
import { CreateRoomDto } from './create-room.dto';

export class UpdateRoomDto extends CreateRoomDto {}

````
