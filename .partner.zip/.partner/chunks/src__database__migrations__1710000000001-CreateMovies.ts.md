# FILE: src/database/migrations/1710000000001-CreateMovies.ts

path: src/database/migrations/1710000000001-CreateMovies.ts
module: database
kind: migration
language: ts
line_count: 54
size_bytes: 2209
sha256: 9033912c477c93ba2c1f0be09019f4288239f373bfeb1e5aaee84a16a45de5c8
updated_at: 2026-04-23T17:17:16.746Z

## SYMBOLS
- CreateMovies1710000000001

## CODE

````ts
import { MigrationInterface, QueryRunner } from 'typeorm';

export class CreateMovies1710000000001 implements MigrationInterface {
  name = 'CreateMovies1710000000001';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`
      CREATE TABLE \`movies\` (
        \`id\`           INT             NOT NULL AUTO_INCREMENT,
        \`slug\`         VARCHAR(255)    UNIQUE,
        \`title\`        VARCHAR(255)    NOT NULL,
        \`poster_url\`   TEXT            NOT NULL,
        \`trailer_url\`  TEXT,
        \`banner_url\`   TEXT,
        \`description\`  TEXT,
        \`duration\`     INT             NOT NULL,
        \`director\`     VARCHAR(200),
        \`actor\`        TEXT,
        \`language\`     VARCHAR(50),
        \`age_rating\`   ENUM('P', 'C13', 'C16', 'C18') NOT NULL,
        \`rated\`        VARCHAR(100),
        \`status\`       ENUM('now_showing', 'upcoming', 'ended') NOT NULL DEFAULT 'upcoming',
        \`release_date\` DATE            NOT NULL,
        \`end_date\`     DATE            NULL,
        \`avg_rating\`   DECIMAL(3,1),
        \`created_at\`   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\`   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT \`PK_movies\` PRIMARY KEY (\`id\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    `);

    await queryRunner.query(
      `CREATE INDEX \`IDX_movies_status\` ON \`movies\`(\`status\`)`,
    );
    await queryRunner.query(
      `CREATE INDEX \`IDX_movies_release_date\` ON \`movies\`(\`release_date\`)`,
    );
    await queryRunner.query(
      `CREATE INDEX \`IDX_movies_age_rating\` ON \`movies\`(\`age_rating\`)`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `DROP INDEX \`IDX_movies_age_rating\` ON \`movies\``,
    );
    await queryRunner.query(
      `DROP INDEX \`IDX_movies_release_date\` ON \`movies\``,
    );
    await queryRunner.query(`DROP INDEX \`IDX_movies_status\` ON \`movies\``);
    await queryRunner.query(`DROP TABLE \`movies\``);
  }
}

````
