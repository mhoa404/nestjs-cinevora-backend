# Architecture Summary

## Project Overview
Đây là backend của Cinevora, xây dựng bằng NestJS, TypeORM và MySQL. Project dùng pnpm để quản lý package, Docker/Docker Compose để chạy dịch vụ, Jenkins để build/deploy, Jest + Supertest để test API/E2E.

## Core Stack
- Framework: NestJS 11
- ORM: TypeORM 0.3
- Database: MySQL
- Validation: class-validator + class-transformer + ValidationPipe
- Auth: JWT access token + refresh token rotation
- Password hashing: bcrypt
- Test: Jest + Supertest + ExcelJS report
- Deploy: Docker Compose + Jenkins

## Application Bootstrap
- Entry point: `src/main.ts`
- Root module: `src/app.module.ts`
- Global guard: `JwtAuthGuard` được đăng ký bằng `APP_GUARD`
- Route public dùng decorator `@Public()` để bỏ qua JWT guard
- Role guard dùng `RolesGuard` + `@Roles(...)` tại controller/route cần phân quyền
- Global validation:
  - `whitelist: true`
  - `forbidNonWhitelisted: true`
  - `transform: true`
  - `stopAtFirstError: true`
- Global exception filter: `HttpExceptionFilter`
- Cookie parser enabled
- CORS enabled theo `app.frontendUrl`

## Config & Database Strategy
- `ConfigModule.forRoot({ isGlobal: true })` load `app.config.ts`, `database.config.ts`, `jwt.config.ts`
- Runtime TypeORM config lấy từ `database.config.ts`
- CLI datasource riêng: `src/database/typeorm.datasource.ts`
- Không dùng `synchronize: true`
- Database thay đổi bằng TypeORM migrations

## Auth Model
Hệ thống auth chia thành 2 flow:

### Web
- `POST /auth/login`: trả `accessToken`, `expiresIn`, `user`; refresh token được set vào cookie httpOnly.
- `POST /auth/refresh`: lấy refresh token từ cookie, rotate token mới và set lại cookie.
- `POST /auth/logout`: lấy refresh token từ cookie, revoke token và clear cookie.

### Mobile
- `POST /auth/mobile/login`: trả cả `accessToken` và `refreshToken` trong response body.
- `POST /auth/mobile/refresh`: gửi refresh token qua body.
- `POST /auth/mobile/logout`: gửi refresh token qua body.

Refresh token được hash SHA-256 trước khi lưu DB. Refresh flow dùng transaction để consume token cũ rồi tạo token mới.

## Main Business Modules

### Auth
Đã có register/login/refresh/logout. Register verify reCAPTCHA, tạo user qua `UsersService`, login cập nhật `lastLoginAt`, refresh token rotation, logout revoke refresh token.

### Users
Service phục vụ auth là chính: tìm theo email/phone/id, tạo user, hash password, kiểm tra trùng email/phone, cập nhật `lastLoginAt`. Controller hiện chưa expose endpoint nghiệp vụ.

### Genres
Đã có CRUD đầy đủ:
- Public: lấy danh sách, lấy chi tiết.
- Admin/Super Admin: tạo, cập nhật, xoá.
- Có trim input, reject whitespace-only, generate slug, unique name theo lowercase, unique slug.
- Chặn xoá nếu genre đang được movie sử dụng.

### Movies
Đã có create/find/update/remove:
- Public: lấy danh sách, lấy theo `slugOrId`.
- Admin/Super Admin: tạo, cập nhật bằng `PUT`, xoá.
- Validate `genreIds`, validate `endDate >= releaseDate`, normalize input, generate slug theo `baseSlug-id`.
- Xoá phim chỉ cho phép khi status là `ended`.

### Rooms
Đã có CRUD:
- Admin/Super Admin only.
- `name` bắt buộc theo format 2 chữ số như `01`, `02`.
- Unique room name.
- `findAll/findOne` trả thêm `totalSeats` bằng relation count.
- Chặn xoá phòng nếu đang có showtime.

### Showtimes
Đã có CRUD chính:
- Public: lấy danh sách, lấy chi tiết.
- Admin/Super Admin: tạo, cập nhật, xoá.
- Tạo nhiều suất chiếu cùng lúc bằng `CreateShowtimeDto` gồm `movieId` và mảng `showtimes`.
- Tự tính `endTime = startTime + movie.duration`.
- Chống trùng lịch theo phòng, có buffer 30 phút sau `endTime`.
- Create chạy transaction `SERIALIZABLE`, lock room pessimistic write.
- Update kiểm tra room/startTime mới, validate overlap, cập nhật giá và status.
- Xoá chỉ cho phép khi phim của suất chiếu có status `ended`.

## Modules Still Mostly Stub / Thin
- bookings: entity có, service/controller còn rỗng.
- payments: service/controller/provider/interface còn rỗng hoặc placeholder.
- promotions: entity có, service/controller còn rỗng.
- seats: entity có, service/controller còn rỗng.

## Testing
Test API hiện tập trung ở:
- auth: register, login, refresh, logout
- genres: create, update, delete
- movies: create, update, delete
- rooms: create, update, delete, get list, get by id

Runner chính: `pnpm test:api`, ánh xạ command trong `test/run-test.ts`.
Report Excel xuất vào `test/results/`.

## Deployment
- `docker-compose.yml` chạy MySQL, backend, Jenkins.
- `Dockerfile` build app production.
- `Dockerfile.jenkins` build Jenkins image.
- `Jenkinsfile` build image backend và deploy qua docker compose.